import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login_tienda_screen.dart';

class QRScreen extends StatefulWidget {
  final String tiendaId;
  final String tiendaNombre;
  final String empresa;

  const QRScreen({
    super.key,
    required this.tiendaId,
    required this.tiendaNombre,
    required this.empresa,
  });

  @override
  State<QRScreen> createState() => _QRScreenState();
}

class _QRScreenState extends State<QRScreen> {
  String _qrData = '';
  int _segundosRestantes = 30;
  Timer? _timerQR;
  Timer? _timerContador;
  bool _generando = false;

  @override
  void initState() {
    super.initState();
    _generarQR();
    _iniciarTimers();
  }

  @override
  void dispose() {
    _timerQR?.cancel();
    _timerContador?.cancel();
    super.dispose();
  }

  void _iniciarTimers() {
    // Renovar QR cada 30 segundos
    _timerQR = Timer.periodic(const Duration(seconds: 30), (_) {
      _generarQR();
      setState(() => _segundosRestantes = 30);
    });

    // Countdown visual cada segundo
    _timerContador = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_segundosRestantes > 0) {
        setState(() => _segundosRestantes--);
      }
    });
  }

  String _generarToken() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final rng = Random.secure();
    return List.generate(12, (_) => chars[rng.nextInt(chars.length)]).join();
  }

  Future<void> _generarQR() async {
    if (_generando) return;
    _generando = true;

    try {
      final nuevoToken = _generarToken();
      final ahora = DateTime.now();
      final expira = ahora.add(const Duration(seconds: 30));

      // IMPORTANTE: el qrData que se codifica en el QR contiene
      // sucursal = widget.tiendaId (que es el doc ID en qr_activos)
      final qrData = {
        'token': nuevoToken,
        'empresa': widget.empresa,
        'sucursal': widget.tiendaId, // <-- doc ID de la tienda
      };

      // Escribir en Firebase con el doc ID = tiendaId
      await FirebaseFirestore.instance
          .collection('qr_activos')
          .doc(widget.tiendaId)
          .set({
            'token': nuevoToken,
            'empresa': widget.empresa,
            'sucursal': widget.tiendaId,
            'nombre_tienda': widget.tiendaNombre,
            'creado': FieldValue.serverTimestamp(),
            'expira': Timestamp.fromDate(expira),
            'activo': true,
          });

      if (mounted) {
        setState(() {
          _qrData = jsonEncode(qrData);
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error generando QR: $e'),
            backgroundColor: const Color(0xFFE63232),
          ),
        );
      }
    } finally {
      _generando = false;
    }
  }

  Future<void> _cerrarSesion() async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: Text(
          'Cerrar sesión',
          style: GoogleFonts.bebasNeue(
            color: Colors.white,
            fontSize: 22,
            letterSpacing: 1,
          ),
        ),
        content: Text(
          '¿Seguro que quieres cerrar sesión en esta tienda?',
          style: GoogleFonts.robotoCondensed(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text(
              'Cerrar sesión',
              style: TextStyle(color: Color(0xFFE63232)),
            ),
          ),
        ],
      ),
    );

    if (confirmar == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('tienda_id');
      await prefs.remove('tienda_nombre');
      await prefs.remove('tienda_empresa');

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginTiendaScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Color del countdown: verde > 10s, amarillo 5-10s, rojo < 5s
    Color colorCountdown;
    if (_segundosRestantes > 10) {
      colorCountdown = const Color(0xFF4eca8b);
    } else if (_segundosRestantes > 5) {
      colorCountdown = Colors.orange;
    } else {
      colorCountdown = const Color(0xFFE63232);
    }

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFFE63232),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'QR DINÁMICO',
              style: GoogleFonts.bebasNeue(
                fontSize: 18,
                letterSpacing: 2,
                color: Colors.white,
              ),
            ),
            Text(
              widget.tiendaNombre,
              style: GoogleFonts.robotoCondensed(
                fontSize: 12,
                color: Colors.white70,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white),
            onPressed: _cerrarSesion,
            tooltip: 'Cerrar sesión',
          ),
        ],
      ),
      body: Center(
        child: _qrData.isEmpty
            ? const CircularProgressIndicator(color: Color(0xFFE63232))
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // QR
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFE63232).withOpacity(0.3),
                          blurRadius: 30,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: QrImageView(
                      data: _qrData,
                      size: 280,
                      backgroundColor: Colors.white,
                      errorCorrectionLevel: QrErrorCorrectLevel.H,
                    ),
                  ),

                  const SizedBox(height: 30),

                  // Nombre tienda
                  Text(
                    widget.tiendaNombre.toUpperCase(),
                    style: GoogleFonts.bebasNeue(
                      fontSize: 26,
                      color: Colors.white,
                      letterSpacing: 2,
                    ),
                  ),

                  const SizedBox(height: 4),

                  Text(
                    widget.empresa,
                    style: GoogleFonts.robotoCondensed(
                      fontSize: 13,
                      color: Colors.white54,
                      letterSpacing: 1,
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Countdown
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: colorCountdown.withOpacity(0.12),
                      border: Border.all(
                        color: colorCountdown.withOpacity(0.5),
                      ),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.timer, color: colorCountdown, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          'Cambia en $_segundosRestantes segundos',
                          style: GoogleFonts.robotoCondensed(
                            fontSize: 14,
                            color: colorCountdown,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Barra de progreso
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 60),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: _segundosRestantes / 30,
                        backgroundColor: Colors.white12,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          colorCountdown,
                        ),
                        minHeight: 6,
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
