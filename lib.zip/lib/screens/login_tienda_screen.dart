import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'qr_screen.dart';

class LoginTiendaScreen extends StatefulWidget {
  const LoginTiendaScreen({super.key});

  @override
  State<LoginTiendaScreen> createState() => _LoginTiendaScreenState();
}

class _LoginTiendaScreenState extends State<LoginTiendaScreen> {
  final _tokenController = TextEditingController();

  List<Map<String, dynamic>> _tiendas = [];
  Map<String, dynamic>? _tiendaSeleccionada;
  bool _cargando = true;
  bool _procesando = false;
  bool _tokenVisible = false;

  @override
  void initState() {
    super.initState();
    _verificarSesionGuardada();
  }

  // Si ya hay sesión guardada, salta directo al QR
  Future<void> _verificarSesionGuardada() async {
    final prefs = await SharedPreferences.getInstance();
    final tiendaId = prefs.getString('tienda_id');
    final tiendaNombre = prefs.getString('tienda_nombre');
    final empresa = prefs.getString('tienda_empresa');

    if (tiendaId != null && tiendaNombre != null && empresa != null) {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => QRScreen(
            tiendaId: tiendaId,
            tiendaNombre: tiendaNombre,
            empresa: empresa,
          ),
        ),
      );
      return;
    }

    await _cargarTiendas();
  }

  Future<void> _cargarTiendas() async {
    try {
      final snap = await FirebaseFirestore.instance
          .collection('qr_tiendas')
          .orderBy('nombre')
          .get();

      setState(() {
        _tiendas = snap.docs.map((doc) {
          final data = doc.data();
          data['id'] = doc.id;
          return data;
        }).toList();
        _cargando = false;
      });
    } catch (e) {
      setState(() => _cargando = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error cargando tiendas: $e'),
            backgroundColor: const Color(0xFFE63232),
          ),
        );
      }
    }
  }

  Future<void> _ingresar() async {
    if (_tiendaSeleccionada == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Selecciona una tienda'),
          backgroundColor: Color(0xFFE63232),
        ),
      );
      return;
    }

    final tokenIngresado = _tokenController.text.trim();
    if (tokenIngresado.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Ingresa el código de acceso'),
          backgroundColor: Color(0xFFE63232),
        ),
      );
      return;
    }

    setState(() => _procesando = true);

    // Verificar token contra Firebase
    final tokenCorrecto = _tiendaSeleccionada!['token_acceso'];
    if (tokenIngresado != tokenCorrecto) {
      setState(() => _procesando = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Código de acceso incorrecto'),
            backgroundColor: Color(0xFFE63232),
          ),
        );
      }
      return;
    }

    // Guardar sesión localmente
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tienda_id', _tiendaSeleccionada!['id']);
    await prefs.setString('tienda_nombre', _tiendaSeleccionada!['nombre']);
    await prefs.setString('tienda_empresa', _tiendaSeleccionada!['empresa']);

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => QRScreen(
          tiendaId: _tiendaSeleccionada!['id'],
          tiendaNombre: _tiendaSeleccionada!['nombre'],
          empresa: _tiendaSeleccionada!['empresa'],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _tokenController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: _cargando
            ? const Center(
                child: CircularProgressIndicator(color: Color(0xFFE63232)),
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 60),
                    Center(
                      child: Text(
                        'QR\nSUCURSAL',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.bebasNeue(
                          fontSize: 52,
                          color: Colors.white,
                          letterSpacing: 4,
                          height: 1.0,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Center(
                      child: Container(
                        width: 60,
                        height: 3,
                        color: const Color(0xFFE63232),
                      ),
                    ),
                    const SizedBox(height: 50),

                    // Label Tienda
                    Text(
                      'TIENDA',
                      style: GoogleFonts.robotoCondensed(
                        fontSize: 13,
                        color: Colors.white70,
                        letterSpacing: 2,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 8),

                    // DropdownButton de tiendas
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<Map<String, dynamic>>(
                          isExpanded: true,
                          value: _tiendaSeleccionada,
                          dropdownColor: Colors.grey[900],
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                          ),
                          hint: Text(
                            'Selecciona tu tienda',
                            style: TextStyle(color: Colors.grey[500]),
                          ),
                          items: _tiendas.map((tienda) {
                            return DropdownMenuItem<Map<String, dynamic>>(
                              value: tienda,
                              child: Text(
                                tienda['nombre'] ?? tienda['id'],
                                style: const TextStyle(
                                  color: Colors.black87,
                                  fontSize: 15,
                                ),
                              ),
                            );
                          }).toList(),
                          onChanged: (val) {
                            setState(() => _tiendaSeleccionada = val);
                          },
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Label Token
                    Text(
                      'CÓDIGO DE ACCESO',
                      style: GoogleFonts.robotoCondensed(
                        fontSize: 13,
                        color: Colors.white70,
                        letterSpacing: 2,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 8),

                    // Campo token
                    TextField(
                      controller: _tokenController,
                      obscureText: !_tokenVisible,
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        letterSpacing: 2,
                      ),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide.none,
                        ),
                        hintText: '••••••••',
                        hintStyle: TextStyle(color: Colors.grey[400]),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 14,
                        ),
                        suffixIcon: IconButton(
                          icon: Icon(
                            _tokenVisible
                                ? Icons.visibility_off
                                : Icons.visibility,
                            color: Colors.grey[600],
                          ),
                          onPressed: () {
                            setState(() => _tokenVisible = !_tokenVisible);
                          },
                        ),
                      ),
                    ),

                    const SizedBox(height: 36),

                    // Botón ingresar
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _procesando ? null : _ingresar,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFE63232),
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: _procesando
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                            : Text(
                                'INGRESAR',
                                style: GoogleFonts.robotoCondensed(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                  letterSpacing: 3,
                                ),
                              ),
                      ),
                    ),

                    const SizedBox(height: 20),
                    Center(
                      child: Text(
                        'Solo para uso del área de sistemas',
                        style: GoogleFonts.robotoCondensed(
                          fontSize: 11,
                          color: Colors.white24,
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
      ),
    );
  }
}
